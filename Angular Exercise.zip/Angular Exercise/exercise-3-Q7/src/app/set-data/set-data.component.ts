import { Component } from '@angular/core';
import { DetailsService } from '../data.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-set-data',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './set-data.component.html',
  styleUrl: './set-data.component.css'
})
export class SetDataComponent {
  newData : string =''

  constructor( private detailsService : DetailsService){}

  setData(){
    this.detailsService.changeData(this.newData)
  }

}
