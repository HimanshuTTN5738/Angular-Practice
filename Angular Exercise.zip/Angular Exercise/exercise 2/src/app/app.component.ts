import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ParentComponentComponent } from './parent-component/parent-component.component'
import { ChildComponentComponent } from './child-component/child-component.component';
import { HighlightDirective } from './highlight.directive';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, ParentComponentComponent,ChildComponentComponent,HighlightDirective],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'exercise-2';
  style  = {
    color:  ''
  }

  hideText : boolean = false

  showAlert = (event : any)=> {
    this.style.color = event
  }

  childClickEvent(event:string) {
   
  }
}
